﻿Partial Class Database1DataSet


    Partial Public Class CarsDataTable
        Private Sub CarsDataTable_ColumnChanging(sender As Object, e As DataColumnChangeEventArgs) Handles Me.ColumnChanging
            If (e.Column.ColumnName = Me.VINColumn.ColumnName) Then
                'Add user code here
            End If

        End Sub

    End Class
End Class

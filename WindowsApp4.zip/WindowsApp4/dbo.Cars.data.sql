﻿INSERT INTO [dbo].[Cars] ([Car ID], [VIN], [Make], [Model], [Year], [Image]) VALUES (1, 1, 1, 1, 1, ILX.gif)
